package com.example.myportfolioapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyportfolioappApplicationTests {

	@Test
	void contextLoads() {
	}

}
