package com.example.myportfolioapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyportfolioappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyportfolioappApplication.class, args);
	}

}
